<?php

/**
 * TODO: impostare il dominio del "remember me" cookie analogamente agli altri.
 */

class myUser extends sfGuardSecurityUser {
  

  
}//myUser