<?php

class adminConfiguration extends sfApplicationConfiguration
{
  public function configure() {
  }
}
