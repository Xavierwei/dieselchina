
<header>

  <a class="logo" href="<?php echo url_for('storeadmin/index'); ?>">DIESEL</a>
    
  <nav>
    <ul class="sprite-menu">
        <li><a class="how-it-works" href="<?php echo url_for('storeadmin/howWorks');?>"><span>How it works</span></a></li>
        <li><a class="help-faq" href="<?php echo url_for('storeadmin/faqNotLogged');?>"><span>Help - Faq</span></a></li>
    </ul>
  </nav>
    
</header>
