<?php

require_once dirname(__FILE__).'/../lib/sl_extra_dataGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sl_extra_dataGeneratorHelper.class.php';

/**
 * sl_extra_data actions.
 *
 * @package    collections
 * @subpackage sl_extra_data
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_extra_dataActions extends autoSl_extra_dataActions
{
}
