<?php

/**
 * sl_extra_data module helper.
 *
 * @package    collections
 * @subpackage sl_extra_data
 * @author     Your name here
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_extra_dataGeneratorHelper extends BaseSl_extra_dataGeneratorHelper
{
}
