<?php

/**
 * sl_world_area module configuration.
 *
 * @package    collections
 * @subpackage sl_world_area
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_world_areaGeneratorConfiguration extends BaseSl_world_areaGeneratorConfiguration
{
}
