<?php

/**
 * sl_world_area module helper.
 *
 * @package    collections
 * @subpackage sl_world_area
 * @author     Your name here
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_world_areaGeneratorHelper extends BaseSl_world_areaGeneratorHelper
{
}
