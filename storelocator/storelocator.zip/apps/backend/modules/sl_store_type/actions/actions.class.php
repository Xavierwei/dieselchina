<?php

require_once dirname(__FILE__).'/../lib/sl_store_typeGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sl_store_typeGeneratorHelper.class.php';

/**
 * sl_store_type actions.
 *
 * @package    collections
 * @subpackage sl_store_type
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_store_typeActions extends autoSl_store_typeActions
{
}
