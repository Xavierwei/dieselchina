<?php

/**
 * sl_product_line module helper.
 *
 * @package    collections
 * @subpackage sl_product_line
 * @author     Your name here
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_product_lineGeneratorHelper extends BaseSl_product_lineGeneratorHelper
{
}
