<?php

require_once dirname(__FILE__).'/../lib/sl_product_lineGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sl_product_lineGeneratorHelper.class.php';

/**
 * sl_product_line actions.
 *
 * @package    collections
 * @subpackage sl_product_line
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_product_lineActions extends autoSl_product_lineActions
{
}
