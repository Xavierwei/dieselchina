<?php

require_once dirname(__FILE__).'/../lib/sl_cityGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sl_cityGeneratorHelper.class.php';

/**
 * sl_city actions.
 *
 * @package    collections
 * @subpackage sl_city
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_cityActions extends autoSl_cityActions
{
}
