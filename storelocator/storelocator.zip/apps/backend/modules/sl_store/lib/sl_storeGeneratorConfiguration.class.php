<?php

/**
 * sl_store module configuration.
 *
 * @package    collections
 * @subpackage sl_store
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_storeGeneratorConfiguration extends BaseSl_storeGeneratorConfiguration
{
}
