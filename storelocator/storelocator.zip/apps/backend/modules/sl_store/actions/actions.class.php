<?php

require_once dirname(__FILE__).'/../lib/sl_storeGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sl_storeGeneratorHelper.class.php';

/**
 * sl_store actions.
 *
 * @package    collections
 * @subpackage sl_store
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_storeActions extends autoSl_storeActions
{
}
