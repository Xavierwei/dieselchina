<?php

require_once dirname(__FILE__).'/../lib/sl_store_newsGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sl_store_newsGeneratorHelper.class.php';

/**
 * sl_store_news actions.
 *
 * @package    collections
 * @subpackage sl_store_news
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_store_newsActions extends autoSl_store_newsActions
{
}
