<?php

/**
 * sl_store_news module helper.
 *
 * @package    collections
 * @subpackage sl_store_news
 * @author     Your name here
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class sl_store_newsGeneratorHelper extends BaseSl_store_newsGeneratorHelper
{
}
