HTML FACEBOOK SPLASH PAGE

<a href="<?php echo proxy_url_for('@facebook_store');?>">ENTER</a>