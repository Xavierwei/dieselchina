<?php

/**
 * itemsMapPluginConfiguration configuration.
 *
 * @package itemsMapPluginConfiguration
 * @subpackage config
 * @author     dtorresan
 */
class itemsMapPluginConfiguration extends sfPluginConfiguration
{
  /**
   * @see sfPluginConfiguration
   */
  public function initialize()
  {
  }
}