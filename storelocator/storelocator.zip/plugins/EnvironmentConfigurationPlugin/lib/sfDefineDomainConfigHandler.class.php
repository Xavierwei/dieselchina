<?php
require_once (dirname(__FILE__).'/../lib/base/baseSfDefineDomainConfigHandler.class.php');
class sfDefineDomainConfigHandler extends baseSfDefineDomainConfigHandler
{
}