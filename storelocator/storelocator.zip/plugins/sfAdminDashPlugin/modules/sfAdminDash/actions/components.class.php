<?php
require_once(dirname(__FILE__).'/../lib/BasesfAdminDashComponents.class.php');

/**
 * sfAdminDash components.
 *
 * @package    plugins
 * @subpackage sfAdminDash
 * @author     kevin
 * @version    SVN: $Id: components.class.php 25203 2009-12-10 16:50:26Z Crafty_Shadow $
 */ 
class sfAdminDashComponents extends BasesfAdminDashComponents
{
}