<?php
require_once(dirname(__FILE__).'/../lib/BasesfAdminDashActions.class.php');

/**
 * sfAdminDash actions.
 *
 * @package    plugins
 * @subpackage sfAdminDash
 * @author     kevin
 * @version    SVN: $Id: actions.class.php 25203 2009-12-10 16:50:26Z Crafty_Shadow $
 */ 
class sfAdminDashActions extends BasesfAdminDashActions
{
  
}
