<?php

class StoreStoreTypeTable extends Doctrine_Table
{
}
