<?php

class StoreExtraDataTable extends Doctrine_Table
{
}
