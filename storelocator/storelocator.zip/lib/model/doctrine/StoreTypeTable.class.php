<?php

class StoreTypeTable extends Doctrine_Table
{
}
