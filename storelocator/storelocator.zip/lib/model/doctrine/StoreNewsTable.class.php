<?php

class StoreNewsTable extends Doctrine_Table
{
}
